package type;

public class Type {
    private int idType;
    private String couleur;
    private String libelle;

    public void setIdType(int idType) {
        this.idType = idType;
    }

    public void setCouleur(String couleur) {
        this.couleur = couleur;
    }

    public void setLibelle(String libelle) {
        this.libelle = libelle;
    }

    public int getIdType() {
        return idType;
    }

    public String getCouleur() {
        return couleur;
    }

    public String getLibelle() {
        return libelle;
    }


}
